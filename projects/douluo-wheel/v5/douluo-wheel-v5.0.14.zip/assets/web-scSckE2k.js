import{W as n}from"./index-CeB6EZOe.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
