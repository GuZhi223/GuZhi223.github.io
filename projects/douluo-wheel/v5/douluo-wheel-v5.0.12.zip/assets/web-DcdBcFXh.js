import{W as n}from"./index-CLtvEf6H.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
