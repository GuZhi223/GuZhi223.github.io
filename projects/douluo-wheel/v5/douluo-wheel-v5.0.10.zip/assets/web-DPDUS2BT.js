import{W as n}from"./index-C-T7jKk9.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
