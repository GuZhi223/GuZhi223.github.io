import{W as n}from"./index-Bi61i7Rc.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
